package filePack;

import java.io.FileOutputStream;

public class fileExmp 
{
	public void createFile()throws Exception
	{
		String name="hi rahul..";
		FileOutputStream fout=new FileOutputStream("abc.txt");
		byte b[]=name.getBytes();
		fout.write(b);
		System.out.println("success");
	}

	public static void main(String[] args)throws Exception 
	{
		fileExmp fe=new fileExmp();
		fe.createFile();

	}

}
