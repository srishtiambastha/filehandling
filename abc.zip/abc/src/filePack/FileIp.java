package filePack;

import java.io.FileInputStream;

public class FileIp 
{
	public void fetchFile()throws Exception
	{
		FileInputStream fin=new FileInputStream("abc.txt");
		int a;
		System.out.println("");
		while ((a=fin.read())!=-1)
			System.out.print((char)a);
		fin.close();
	}

	public static void main(String[] args)throws Exception
	{
		FileIp fi=new FileIp();
		fi.fetchFile();
	}

}
